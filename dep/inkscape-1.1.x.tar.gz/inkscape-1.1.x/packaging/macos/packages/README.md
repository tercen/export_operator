# packages

A package is a file that contains everything regarding a specific piece of software or functionality in one place, to be sourced by other scripts. All functions and variables have the package's name as prefix. In terms of modularization and encapsulation, it is the preferred approach to group things together as packages in contrast to having things scattered around different files and locations.
