# patches

This is a customized copy of [gtk-osx](https://gitlab.gnome.org/GNOME/gtk-osx)'s `patches` folder.