# What is this

The development repository for building/packaging Inkscape on macOS,
[mibap](https://github.com/dehesselle/mibap), has begun to source out
functions into a common function library, [bash_d](https://github.com/dehesselle/bash_d), for better reusability across different projects.

The files in here have been copied from that repository as we only need a few of them and to not include a foreign submodule here.
