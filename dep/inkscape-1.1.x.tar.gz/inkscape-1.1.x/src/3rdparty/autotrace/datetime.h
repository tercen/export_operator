char *at_time_string(void);
