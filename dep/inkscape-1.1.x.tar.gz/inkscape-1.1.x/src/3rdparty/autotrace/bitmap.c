/* bitmap.c: operations on bitmaps. */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif /* Def: HAVE_CONFIG_H */

#include "bitmap.h"
#include "xstd.h"
