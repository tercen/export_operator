#ifndef __CR_LIBXML_NODE_IFACE_H__
#define __CR_LIBXML_NODE_IFACE_H__

#include <glib.h>
#include "cr-node-iface.h"

G_BEGIN_DECLS

extern CRNodeIface const cr_libxml_node_iface;

G_END_DECLS


#endif/*__CR_LIBXML_NODE_IFACE_H__*/
