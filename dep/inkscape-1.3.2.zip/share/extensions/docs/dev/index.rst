inkex (and core Extensions) development
=======================================

.. toctree::
   :maxdepth: 2

   getting-started
   Writing unit tests <../authors/unit-tests>