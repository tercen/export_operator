# Contributing

See https://inkscape.gitlab.io/extensions/documentation/dev/getting-started.html for hints to
setup your development environment.