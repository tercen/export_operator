Directory    | Description
-------------|--------------------------------------------------------------
`attributes` |
`branding`   | Official visual collateral
`examples`   | Shareable example drawings
`extensions` | Pluggable scripts runnable by Inkscape
`filters`    | Custom SVG filters loaded at runtime, under Effects > Filters
`fonts`      |
`gradients`  |
`icons`      | Program icons following the freedesktop.org icon scheme.
`keys`       |
`markers`    |
`palettes`   |
`patterns`   |
`screens`    |
`symbols`    |
`templates`  |
`tutorials`  |
`ui`         |
